# react-ts-bootstrap-starter

Get up and running with React, React Router, TypeScript, SaSS and Bootstrap without the hassle.

## Instructions

Clone the repository and start the development server.

```bash
$ git clone https://github.com/anamake/react-ts-bootstrap-starter.git
$ cd react-ts-bootstrap-starter
react-ts-bootstrap-starter $ yarn
react-ts-bootstrap-starter $ yarn start
```
