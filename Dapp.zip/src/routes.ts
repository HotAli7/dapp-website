import App from "./App";
import Home from "./pages/Home";
import Dapp from "./pages/Dapp";

const routes = [
  {
    path: "/",
    component: Home
  },
  {
    path: "/home",
    component: Home
  },
  {
    path: "/dapp",
    component: Dapp
  }
];

export default routes;
